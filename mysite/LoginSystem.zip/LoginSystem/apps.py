from django.apps import AppConfig


class LoginsystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'LoginSystem'
